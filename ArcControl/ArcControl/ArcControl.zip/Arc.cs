﻿using System.Linq;
using Windows.Foundation;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Shapes;

namespace ArcControl
{
    public class Arc : Canvas
    {
        private readonly GeometryHelper _geometryHelper = new GeometryHelper();
        private readonly MathHelper _mathHelper = new MathHelper();
        private Point _outerCurrentPoint;
        private Point _startPoint;
        private int StartOuterAngle = 0;

        public Arc()
        {
            Loaded += OnLoaded;
        }

        private double CentreX
        {
            get
            {
                return OuterRingRadius / 2;
            }
        }

        private double CentreY
        {
            get
            {
                return OuterRingRadius + (StripWidth / 2);
            }
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            Draw();
        }

        private void Draw()
        {
            _startPoint = new Point(CentreX, CentreY);
            Children.Clear();

            //The control starts at x=0, y=1 - in the middle of the ring strip
            _outerCurrentPoint = new Point(CentreX, 2* (StripWidth / 2));

            double outerAngle = (double)((double)OuterCurrentValue / (double)OuterRingMaxValue) * 360;
            if (outerAngle >= 360)
            {
                outerAngle = 359.999;   //360 = 0 - so we need to have a little smaller value
            }
            _outerCurrentPoint = _mathHelper.ScaleUnitCirclePoint(new Point(CentreX, CentreY), outerAngle, OuterRingRadius);

            double rawValue = CreateSegment(Name + "OuterRadialStrip", OuterRingRadius, _outerCurrentPoint, OuterRingColor, outerAngle);
        }

        private double CreateSegment(string name, double radius, Point currentPoint, Color color, double angle)
        {
            _geometryHelper.SetColours(new SolidColorBrush(color));

            Path radialStrip = _geometryHelper.GetCircleSegment(_startPoint, //The centre of the circle
                currentPoint, radius, StripWidth, angle);

            radialStrip.IsHitTestVisible = false;
            radialStrip.Name = name;
            radialStrip.SetValue(ZIndexProperty, -2);

            Children.Add(radialStrip);

            //Return the angle translated into a number value
            return (angle / 360.0);
        }


        #region Dependency Properties

        public static readonly DependencyProperty OuterRingRadiusProperty = DependencyProperty.Register("OuterRingRadius", typeof(double), typeof(Arc), new PropertyMetadata(100.0));

        public double OuterRingRadius
        {
            get
            {
                return (double)GetValue(OuterRingRadiusProperty);
            }
            set
            {
                SetValue(OuterRingRadiusProperty, value);
            }
        }

        public static readonly DependencyProperty StripWidthProperty = DependencyProperty.Register("StripWidth", typeof(double), typeof(Arc), new PropertyMetadata(10.0));

        public double StripWidth
        {
            get
            {
                return (double)GetValue(StripWidthProperty);
            }
            set
            {
                SetValue(StripWidthProperty, value);
            }
        }

        public Color OuterRingBackgroundColor
        {
            get
            {
                return (Color)GetValue(OuterRingBackgroundColorProperty);
            }
            set
            {
                SetValue(OuterRingBackgroundColorProperty, value);
            }
        }

        public static readonly DependencyProperty OuterRingBackgroundColorProperty = DependencyProperty.Register("OuterRingBackgroundColor", typeof(Color), typeof(Arc), new PropertyMetadata(Colors.Transparent));

        public static readonly DependencyProperty OuterRingColorProperty = DependencyProperty.Register("OuterRingColor", typeof(Color), typeof(Arc), new PropertyMetadata(Colors.White));

        public Color OuterRingColor
        {
            get
            {
                return (Color)GetValue(OuterRingColorProperty);
            }
            set
            {
                SetValue(OuterRingColorProperty, value);
            }
        }

        public static readonly DependencyProperty OuterCurrentValueProperty = DependencyProperty.Register("OuterCurrentValue", typeof(int), typeof(Arc), new PropertyMetadata(0, OnOuterCurrentValuePropertyChanged));

        private static void OnOuterCurrentValuePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as Arc;
            control.Draw();
        }

        public int OuterCurrentValue
        {
            get
            {
                return (int)GetValue(OuterCurrentValueProperty);
            }
            set
            {
                SetValue(OuterCurrentValueProperty, value);
            }
        }

        public static readonly DependencyProperty OuterRingMaxValueProperty = DependencyProperty.Register("OuterRingMaxValue", typeof(int), typeof(Arc), new PropertyMetadata(100));

        public int OuterRingMaxValue
        {
            get
            {
                return (int)GetValue(OuterRingMaxValueProperty);
            }
            set
            {
                SetValue(OuterRingMaxValueProperty, value);
            }
        }

        #endregion
    }
}